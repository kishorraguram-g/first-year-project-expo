import pandas as pd
import random
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
def predict(**kwargs):
    
    cp_values = [0, 1, 2, 3] 
    restecg_values = [0, 1]  
    thalach_limit = (120, 200)  
    exang_values = [0, 1]  
    oldpeak_limit = (0.0, 4.0)  
    slope_values = [0, 1, 2]  
    ca_values = [0, 1, 2, 3]  
    thal_values = [0, 1, 2, 3]
    cp = None
    if kwargs['age'] >=60 and (kwargs['sugar'] >= 150 or kwargs['pressure']>=150):
        cp = random.choice([1,2,3])
    else:
        cp = 0
    patient_data = {
        "age": kwargs['age'],
        "sex": kwargs['sex'],
        "cp": cp,
        "trestbps": kwargs['pressure'],
        "chol": kwargs['chol'],
        "fbs": 1 if kwargs['sugar'] >=100 else 0,
       "restecg": random.choice(restecg_values),
        "thalach": random.randint(thalach_limit[0], thalach_limit[1]),
        "exang": random.choice(exang_values),
        "oldpeak": round(random.uniform(oldpeak_limit[0], oldpeak_limit[1]), 1),
        "slope": random.choice(slope_values),
        "ca": random.choice(ca_values),
        "thal": random.choice(thal_values)
    }
    
    df = pd.read_csv(r"C:\Users\harih\Downloads\heartdiseasedataset (1).csv")
    lc =LabelEncoder()
    df["target"]=lc.fit_transform(df["target"])
    df1 = df.pop('target')
   
    x_train,x_test,y_train,y_test = train_test_split(df,df1,test_size = 0.2)
   
    lr = LogisticRegression()
    lr.fit(x_train,y_train)
    sample = patient_data
    sample = pd.DataFrame.from_dict([sample])
    pred_samp = lr.predict(sample)
    result = pred_samp[0]
    return result